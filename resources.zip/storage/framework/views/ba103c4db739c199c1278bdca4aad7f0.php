<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="SoftNovaIT provides expert Web Design, Software Development, Mobile Apps, Data Science, AI Applications, and Security solutions.">
    <link rel="icon" href="<?php echo e(asset('images/favicon.ico')); ?>" type="image/x-icon">
    <title><?php echo $__env->yieldContent('title', 'SoftNovaIT'); ?></title>
     <script src="https://cdn.tailwindcss.com"></script>
    <?php echo $__env->yieldPushContent('head-scripts'); ?> 
    <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap">
</head>
<body class="bg-white text-gray-900">
    <?php echo $__env->make('partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- Load jQuery and main scripts at the end of the body -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?> 
</body>
</html>
<?php /**PATH D:\Laravel_Projects\SoftNovaIT_Laravel_03\resources\views/layouts/app.blade.php ENDPATH**/ ?>